
import Control.Monad.Writer

--foo :: Writer String -> Writer ()

foo :: Writer String ()
foo = do
  tell "hello, "
  tell "world!"
  
bar :: Writer String ()
bar = do
  tell "fuck you, "
  foo
  
tellLn :: MonadWriter String m => String -> m ()
tellLn w = do
  tell w
  tell "\n"
  
main :: IO ()
main = do
  putStrLn (execWriter bar)